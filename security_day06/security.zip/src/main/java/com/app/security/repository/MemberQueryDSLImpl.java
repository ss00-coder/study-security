package com.app.security.repository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
public class MemberQueryDSLImpl implements MemberQueryDSL {
}
