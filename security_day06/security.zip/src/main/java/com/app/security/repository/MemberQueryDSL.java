package com.app.security.repository;

public interface MemberQueryDSL {
}
