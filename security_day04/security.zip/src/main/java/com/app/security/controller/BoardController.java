package com.app.security.controller;

import com.app.security.provider.MemberDetail;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/board/*")
public class BoardController {
    @GetMapping("list")
    public void goToListForm(@AuthenticationPrincipal MemberDetail memberDetail){
        log.info("=================== {}", memberDetail.toString());
    }
}
